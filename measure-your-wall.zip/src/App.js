import React, { Component } from "react";
import Page1 from "./Page1.js";
import Calc from "./Calc.js";
import ScaleSlider from "./Slider.js";
import Selection from "./Selection.js";
import Results from "./Results.js";

// Main Page
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      buttonfirst: true,
      buttonsecond: false,
      buttonthird: false,
      buttonfourth: false,
      Area: 0,
      Min: 0,
      Max: 0,
      ChosenStyle: "",
      ChosenFinish: ""
    };
    this.nextpageclick1 = this.nextpageclick1.bind(this);
    this.nextpageclick3 = this.nextpageclick3.bind(this);
    this.nextpageclick4 = this.nextpageclick4.bind(this);
    this.nextpageclick5 = this.nextpageclick5.bind(this);
  }
  // Handling the buttons from each button click
  //to control the conditional rendering for each page.
  nextpageclick1() {
    this.setState({
      buttonfirst: false,
      buttonsecond: true,
      buttonthird: false,
      buttonfourth: false
    });
  }

  nextpageclick3() {
    this.setState({
      buttonfirst: false,
      buttonsecond: false,
      buttonthird: false,
      buttonfourth: true
    });
  }
  nextpageclick4() {
    this.setState({
      buttonfirst: true,
      buttonsecond: true,
      buttonthird: true,
      buttonfourth: true
    });
  }
  nextpageclick5() {
    this.setState({
      buttonfirst: true,
      buttonsecond: false,
      buttonthird: false,
      buttonfourth: false,
      Area: "",
      Min: "",
      Max: "",
      ChosenStyle: "",
      ChosenFinish: ""
    });
  }

  //callbacks for data from the different componants
  handleCallback = (childData) => {
    this.setState({ Area: childData });
    this.setState({
      buttonfirst: false,
      buttonsecond: false,
      buttonthird: true,
      buttonfourth: false
    });
  };
  handleCallbackSlider = (min, max) => {
    this.setState({ Min: min, Max: max });
    this.setState({
      buttonfirst: false,
      buttonsecond: false,
      buttonthird: false,
      buttonfourth: true
    });
  };

  handleCallbackSelect = (Style) => {
    this.setState({ ChosenStyle: Style, ChosenFinish: "" });
  };
  handleCallbackFinish = (Finish) => {
    this.setState({ ChosenFinish: Finish });
  };
  render() {
    //Page 1 contains the first page- images and a button which will be linked to Calc (Page2)
    //Calc is the multiplication function- need to add an "Add measurement" section
    //ScaleSlider is the sliding scale- the values save as value1 and value2, have an error message now.
    //Selection will be the next page- have it done, will have to add an option to save your choice
    //will link it with a map function for the options.
    //Results contains the Map, filter and calculator function.

    //the next page classes control the conditional rendering of what page appears
    //using boolean values

    return (
      // Bootstrap: adding a classname Container. All of our content will be
      //within this container and responsive to any device
      <div className="App">
        <div class="container">
          {this.state.buttonfirst && !this.state.buttonsecond && (
            <div>
              <Page1 />
              <NextPage buttonHandler={this.nextpageclick1} />
            </div>
          )}

          {!this.state.buttonfirst && this.state.buttonsecond && (
            <div>
              <Calc parentCallback={this.handleCallback} />
            </div>
          )}

          {!this.state.buttonsecond && this.state.buttonthird && (
            <div>
              <ScaleSlider parentCallback2={this.handleCallbackSlider} />
            </div>
          )}

          {!this.state.buttonthird && this.state.buttonfourth && (
            <div>
              <Selection
                parentCallback3={this.handleCallbackSelect}
                parentCallback4={this.handleCallbackFinish}
              />
              <br />
              <p>
                You have selected as your finish: {this.state.ChosenStyle}
                <br />
                You have selected as your style: {this.state.ChosenFinish}
              </p>
              <NextPage4
                props1={this.state.ChosenStyle}
                props2={this.state.ChosenFinish}
                buttonHandler={this.nextpageclick4}
              />
            </div>
          )}

          {this.state.buttonfirst &&
            this.state.buttonsecond &&
            this.state.buttonthird &&
            this.state.buttonfourth && (
              <div>
                <Results
                  Propsforarea={this.state.Area}
                  Propsformin={this.state.Min}
                  Propsformax={this.state.Max}
                  Propsforstyle={this.state.ChosenStyle}
                  Propsforfinish={this.state.ChosenFinish}
                />
                <Homebutton buttonHandler={this.nextpageclick5} />
              </div>
            )}
        </div>
      </div>
    ); // end of return statement
  } // end of render function
} // end of class

//the classes for the nextpage buttons
class NextPage extends Component {
  render() {
    // get the buttonHandler prop from
    // this.props - we use this in the onClick
    // function in the button below.
    const buttonHandler = this.props.buttonHandler;

    return (
      <div className="NextPageComponent">
        <br />
        <button type="button" class="btn btn-primary" onClick={buttonHandler}>
          Let's Get Started
        </button>
      </div>
    ); // end of return statement
  } // end of render function
} // end of class

class NextPage4 extends Component {
  render() {
    // get the buttonHandler prop from
    // this.props - we use this in the onClick
    // function in the button below.
    const buttonHandler = this.props.buttonHandler;
    const Style = this.props.props1;
    const Finish = this.props.props2;
    const isenabled = Style.length > 0 && Finish.length > 0;
    return (
      <div className="NextPageComponent">
        <br />
        <button
          disabled={!isenabled}
          type="button"
          class="btn btn-primary"
          onClick={buttonHandler}
        >
          See Your Results
        </button>
      </div>
    ); // end of return statement
  } // end of render function
} // end of class
class Homebutton extends Component {
  render() {
    // get the buttonHandler prop from
    // this.props - we use this in the onClick
    // function in the button below.
    const buttonHandler = this.props.buttonHandler;

    return (
      <div className="NextPageComponent">
        <br />
        <button type="button" class="btn btn-primary" onClick={buttonHandler}>
          Return to Start
        </button>
      </div>
    ); // end of return statement
  } // end of render function
} // end of class
export default App;
