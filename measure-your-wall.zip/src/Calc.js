import React, { Component } from "react";
//import Logo from "./Logo";
import Wallmeasure from "./images/Wallmeasurement.png";

class Calc extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Height: "",
      Width: "",
      Area: ""
    };
    this.onTextBoxChange = this.onTextBoxChange.bind(this);
    this.onTextBoxChangeWidth = this.onTextBoxChangeWidth.bind(this);
  } // end constructor
  //the events controlling the change in text box and callback

  onTextBoxChange(event) {
    // event is understood by Javascript to be a change to a UI item

    this.setState({ Height: event.target.value });
  }
  onTextBoxChangeWidth(event) {
    // event is understood by Javascript to be a change to a UI item
    this.setState({ Width: event.target.value });
  }

  onTrigger = (event) => {
    this.props.parentCallback(this.state.Area);
    event.preventDefault();
  };
  //the main rendering of the caluclation page

  render() {
    this.state.Area = this.state.Height * this.state.Width;

    return (
      <div className="Calc">
        <h1>1. Measure Your Wall</h1>
        <img src={Wallmeasure} alt="Wall measuring " width="300" height="150" />
        <Height Height={this.state.Height} onChange={this.onTextBoxChange} />
        <Width Width={this.state.Width} onChange={this.onTextBoxChangeWidth} />
        The area covered is [{this.state.Height}] * [{this.state.Width}] ={" "}
        {this.state.Area} metres squared.
       {/*conditional rendering of buttons*/}
       
        {!this.state.Area > 0 && (
          <p>Area must be a value above 0 to continue</p>
        )}
        {this.state.Area > 0 && <NextPage2 buttonHandler={this.onTrigger} />}
      </div>
    ); // end of return statement
  } // end of render function
} // end of class

//classes controlling height and width variables
class Height extends Component {
  render() {
    // this.props are the properties which are provided or passed
    // to this component. We have the height and we have the
    // onChange function.
    const height = this.props.height;
    const onChangeFromProps = this.props.onChange;

    return (
      <div className="Heightform">
        <hr />
        <form>
          <b>Height: </b>
          <input
            type="text"
            class="form-control"
            value={height}
            onChange={onChangeFromProps}
          />
        </form>
        <br />
      </div>
    );
  }
} // close the height Component
class Width extends Component {
  render() {
    // this.props are the properties which are provided or passed
    // to this component. We have the width and we have the
    // onChange function.
    const width = this.props.width;
    const onChangeFromProps = this.props.onChange;

    return (
      <div className="Widthform">
        <form>
          <div class="input-group input-group-sm"></div>
          <b>Width: </b>

          <input
            type="text"
            class="form-control"
            value={width}
            onChange={onChangeFromProps}
          />
        </form>
        <hr />
      </div>
    );
  }
} // close the width Component
class NextPage2 extends Component {
  render() {
    // get the buttonHandler prop from
    // this.props - we use this in the onClick
    // function in the button below.
    const buttonHandler = this.props.buttonHandler;

    return (
      <div className="NextPageComponent">
        <br />

        <button type="button" class="btn btn-primary" onClick={buttonHandler}>
          Set Your Budget
        </button>
      </div>
    ); // end of return statement
  } // end of render function
} // end of class

export default Calc;
