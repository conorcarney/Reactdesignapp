import React from "react";

import Zinclogo from "./images/Zinclogo2.png";
function Logo() {
  return (
    <div className="Logo">
      <img
        src={Zinclogo}
        alt="Zinc"
        width="300"
        height="169
      "
      />
    </div>
  );
}
export default Logo;
