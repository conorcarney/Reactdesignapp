import React, { Component } from "react";
import Logo from "./Logo";
import Measure from "./images/1measure.jpeg";
import Budget from "./images/2budget.jpeg";
import Select from "./images/3select.jpeg";

class Page1 extends Component {
 
//homepage
  render() {
    return (
      <div className="Page1">
        <Logo />
        <img src={Measure} alt="measure" width="300" />
        <br />
        <br />
        <br />
        <img src={Budget} alt="budget" width="300" />
        <br />
        <br />
        <br />
        <img src={Select} alt="select" width="300" />
        <br />
      </div>
    );
  }
}

export default Page1;
