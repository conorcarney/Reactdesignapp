import React, { Component } from "react";

class Results extends Component {
  constructor(props) {
    super(props);

    // create three state variables.
    // apiData is an array to hold our JSON data
    // isFetched indicates if the API call has finished
    // errorMsg is either null (none) or there is some error
    this.state = {
      apiData: [],
      isFetched: false,
      errorMsg: null
    };
  }
  // componentDidMount() is invoked immediately after a
  // component is mounted (inserted into the tree)

  async componentDidMount() {
    try {
      const API_URL =
        "https://raw.githubusercontent.com/conorcarney/CS385Zinc/main/ZincProductsAPI.json";
      // Fetch or access the service at the API_URL address
      const response = await fetch(API_URL);
      // wait for the response. When it arrives, store the JSON version
      // of the response in this variable.
      const jsonResult = await response.json();

      // update the state variables correctly.
      this.setState({ apiData: jsonResult.products });
      this.setState({ isFetched: true });
    } catch (error) {
      // In the case of an error ...
      this.setState({ isFetched: false });
      // This will be used to display error message.
      this.setState({ errorMsg: error });
    } // end of try catch
  } // end of componentDidMount()

  render() {
    if (this.state.errorMsg) {
      return (
        <div className="error">
          <h2>We're very sorry: An error has occured in the API call</h2>

          <p>The error message is: {this.state.errorMsg.toString()}</p>
        </div>
      ); // end of return.
    } else if (this.state.isFetched === false) {
      return (
        <div className="fetching">
          <h2>Just a moment...</h2>
          <p>Your selection will be ready very soon.</p>
        </div>
      ); // end of return
    } else {
      // Our filter and price formula is called in this function
      function finishFilter(chosenfinish, chosenstyle, min, max, area) {
        return function Calculating(Products) {
          let total = (area / Products.unitArea) * Products.unitPrice;

          return (
            Products.finish === chosenfinish &&
            Products.style === chosenstyle &&
            total > min &&
            total < max
          );
        };
      }
      // the variables taken in by props from the App.js page
      const Area = this.props.Propsforarea;
      const Min = this.props.Propsformin;
      const Max = this.props.Propsformax;
      const Style = this.props.Propsforstyle;
      const Finish = this.props.Propsforfinish;

      //The rendering of the tables containing the product results and other interests

      return (
        <div className="App">
          <div className="ProductsTable">
            <div class="container">
              <h2>Your Options</h2>

              <table border="1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Image</th>
                    <th>Product Description</th>
                    <th>Units needed </th>
                    <th>Total Price</th>
                  </tr>
                </thead>
{/*the map and filter function of the app, calling from the API*/ }
                <tbody>
                  {this.state.apiData
                    .filter(finishFilter(Style, Finish, Min, Max, Area))
                    .map((s) => (
                      <tr key={s.description}>
                        <td>
                          <img
                            src={s.image}
                            width="100"
                            height="100"
                            alt={s.description}
                          />
                        </td>
                        <td>
                          {s.description} <br />
                          {
                            <a href={s.webpage}> Click here to purchase </a>
                          }{" "}
                        </td>
                        <td>{Math.ceil(Area / s.unitArea)}</td>
                        <td>€{Math.ceil(s.unitPrice * (Area / s.unitArea))}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
              <h2>You May Also Need</h2>
              <table border="1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Image</th>
                    <th>Product Description</th>
                    <th>Units Needed</th>
                    <th>Total Price</th>
                  </tr>
                </thead>

                {Style === "Paint" && (
                  <tbody>
                    <tr>
                      <td>
                        <img
                          src="https://media.screwfix.ie/is/image//ae235?src=ae235/616FG_P&$prodImageMedium$"
                          width="100"
                          height="100"
                          alt="Primer"
                        />
                      </td>
                      <td>
                        Quick Dry Primer & Undercoat <br />
                        {
                          <a
                            href={
                              "https://www.screwfix.ie/p/no-nonsense-primer-undercoat-750ml/616FG?gclid=CjwKCAiAt9z-BRBCEiwA_bWv-HFzpvrQpX7ydp0QNos4vo4YYiCz3BCIe6AwcqmJkLKqitOL6mu6lhoCs5UQAvD_BwE&gclsrc=aw.ds"
                            }
                          >
                            Click here to purchase{" "}
                          </a>
                        }
                      </td>
                      <td>{Math.ceil(Area / 12)}</td>
                      <td>€{Math.ceil(7 * (Area / 12))}</td>
                    </tr>
                    <tr>
                      <img
                        src="https://media.screwfix.ie/is/image//ae235?src=ae235/9231X_P&$prodImageMedium$"
                        width="100"
                        height="100"
                        alt ="Screwups"
                      />
                      <td>
                        Roller & Brush Set <br />
                        {
                          <a
                            href={
                              "https://www.screwfix.ie/p/harris-trade-medium-pile-micropoly-roller-brush-set-7-pieces/9231x"
                            }
                          >
                            Click here to purchase{" "}
                          </a>
                        }
                      </td>
                      <td> 1 </td>
                      <td>€7</td>
                    </tr>
                  </tbody>
                )}
                {Style === "Wallpaper" && (
                  <tbody>
                    <tr>
                      <td>
                        <img
                          src="https://www.littlegreene.ie/media/catalog/product/cache/2/image/500x430/17f82f742ffe127f42dca9de82fb58b1/2/_/2.5kg_copy.jpg"
                          width="100"
                          height="100"
                          alt ="Wallpaperpaste"
                        />
                      </td>
                      <td>
                        Ready Mixed Wallpaper Paste
                        <br />
                        {
                          <a
                            href={
                              "https://www.littlegreene.ie/lg-wallpaper-paste-2-5-kg-standard-paste"
                            }
                          >
                            Click here to purchase{" "}
                          </a>
                        }
                      </td>
                      <td>{Math.ceil(Area / 15)}</td>
                      <td>€{Math.ceil(20 * (Area / 15))}</td>
                    </tr>
                    <tr>
                      <td>
                        <img
                          src="https://media.screwfix.ie/is/image//ae235?src=ae235/45599_P&$prodImageMedium$"
                          width="100"
                          height="100"
                          alt = "hanging set"
                        />
                      </td>
                      <td>
                        Wallpaper Hanging Set
                        <br />
                        {
                          <a
                            href={
                              "https://www.screwfix.ie/p/harris-wallpaper-hanging-set-6-piece-set/45599"
                            }
                          >
                            Click here to purchase{" "}
                          </a>
                        }
                      </td>
                      <td> 1 </td>
                      <td>€16</td>
                    </tr>
                  </tbody>
                )}
              </table>
              {/* Data brought from parent to child */}
              <p>
                {" "}
                Area: {Area} metres squared Style: {Style} Finish: {Finish} Max
                Price: {Max} Min Price: {Min}{" "}
              </p>
            </div>
          </div>
        </div>
      ); // end of return
    } // end of the else statement.
  } // end of render()
} // end of Results class
export default Results;
