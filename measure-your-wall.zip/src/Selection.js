import React, { Component } from "react";
import "./styles.css";
import WallpaperExample from "./images/WallpaperExample.jpg";
import PaintExample from "./images/PaintExample.jpg";
import Bold from "./images/Bold.jpg";
import Neutral from "./images/Neutral.jpg";
import Pastel from "./images/Pastel.jpg";
import Rich from "./images/Rich.jpg";
import Classic from "./images/Classic.jpg";
import Graphic from "./images/Graphic.jpg";
import Retro from "./images/Retro.jpg";
import Floral from "./images/Floral.jpg";

class Selection extends Component {
  constructor(props) {
    super(props);
    this.state = { paintclick: false, wallpaperclick: false };
  }
  //Triggers and callbacks for each click on each picture,
  //and controls boolean values for conditional rendering

  onTriggerPaint = (event) => {
    this.setState({ paintclick: true, wallpaperclick: false });
    this.props.parentCallback3("Paint");
    event.preventDefault();
  };
  onTriggerWall = (event) => {
    this.setState({ wallpaperclick: true, paintclick: false });
    this.props.parentCallback3("Wallpaper");
    event.preventDefault();
  };
  onTriggerBold = (event) => {
    this.props.parentCallback4("Bold");
    event.preventDefault();
  };
  onTriggerPastel = (event) => {
    this.props.parentCallback4("Pastel");
    event.preventDefault();
  };
  onTriggerRich = (event) => {
    this.props.parentCallback4("Rich");
    event.preventDefault();
  };
  onTriggerNeutral = (event) => {
    this.props.parentCallback4("Neutral");
    event.preventDefault();
  };
  onTriggerClassic = (event) => {
    this.props.parentCallback4("Classic");
    event.preventDefault();
  };
  onTriggerFloral = (event) => {
    this.props.parentCallback4("Floral");
    event.preventDefault();
  };
  onTriggerRetro = (event) => {
    this.props.parentCallback4("Retro");
    event.preventDefault();
  };
  onTriggerGraphic = (event) => {
    this.props.parentCallback4("Graphic");
    event.preventDefault();
  };
  // Main rendering of selection
  render() {
    return (
      <div className="Decision">
        <h1>3. Choose Your Finish</h1>
        <div className="productsContainer">
        <div className = "products">
        <Paint PaintButtonClick={this.onTriggerPaint} />
        
        <Wallpaper WallpaperClick={this.onTriggerWall} />
        
       </div>
        </div>
        
       {/*Conditional rendering and bootstrap for paint options */}
        {this.state.paintclick === true && this.state.wallpaperclick === false && (
          <div className="PaintSelection">
            <div className="productsContainer">
        <div className = "products">
                <img
                  src={Bold}
                  onClick={this.onTriggerBold}
                  width="250"
                  height="200"
                  alt = "bold"
                />
               
                <img
                  src={Pastel}
                  onClick={this.onTriggerPastel}
                  width="250"
                  height="200"
                  alt = "Pastel"
                />
                
        </div>
        </div>
        <div className="productsContainer">
        <div className = "products">
                
                <img
                  src={Rich}
                  onClick={this.onTriggerRich}
                  width="250"
          height="200"
          alt = "Rich"
                />
                
                
                <img
                  src={Neutral}
                  onClick={this.onTriggerNeutral}
                  width="250"
          height="200"
          alt = "Neutral"
                />

                
                </div>
        </div>
              
           
          </div>
        )}
{/*Conditional rendering and bootstrap for wallpaper options */}
        {this.state.wallpaperclick === true && this.state.paintclick === false && (
          <div className="WallpaperSelection">
            <div class="row">
              <div class="column">
              <div className="productsContainer">
        <div className = "products">
                <img
                  src={Classic}
                  onClick={this.onTriggerClassic}
                  width = "250"
                  height="200"
                   alt = "Classic"
                />
                
                <img
                  src={Floral}
                  onClick={this.onTriggerFloral}
                  width="250"
                  height="200"
                  alt = "Floral"
                />
                
                </div>
                </div>
         <div className="productsContainer">
        <div className = "products">
                <img
                  src={Retro}
                  onClick={this.onTriggerRetro}
                  width="250"
                  height="200"
                  alt = "Retro"
                />
               
                <img
                  src={Graphic}
                  onClick={this.onTriggerGraphic}
                  width="250"
                  height="200"
                  alt = "Graphic"
                />
                
                 </div> {/*ENd of products div */}
              </div>{/*End of productscontainer div */}
              </div>{/*End of column div */}
            </div>{/*End of rows div */}
          </div>         
          )}
        
      </div> 
    );
  }
}

//classes of each image style
class Paint extends Component {
  render() {
    const Paintclick = this.props.PaintButtonClick;
    return (
      <div className="Paint">
        
        <img src={PaintExample} 
        onClick={Paintclick} className ="image" 
        width="250"
          height="200"
          alt = "paint" />
        <p>Paint</p>
      </div>
    );
  }
}
class Wallpaper extends Component {
  render() {
    const Wallpaperclick = this.props.WallpaperClick;
    return (
      <div className="Wallpaper">
        
        <img
          src={WallpaperExample}
          onClick={Wallpaperclick}
          width="250"
          height="200"
          alt ="wallpaper"
        />
         <p>Wallpaper</p>
      </div>
    );
  }
}

export default Selection;
