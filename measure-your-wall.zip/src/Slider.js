import React, { Component } from "react";

import { Slider } from "react-semantic-ui-range";
import "semantic-ui-css/semantic.min.css";
import { Segment, Grid, Label } from "semantic-ui-react";

class SliderScale extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value1: 0,
      value: 0,
      value2: 0
    };
  }
// handling the change of state on sliders
  handleValueChange(e, { value }) {
    this.setState({
      value: value
    });
  }
  //callback to parent app
   onTrigger = (event) => {
    const min = this.state.value1;
    const max = this.state.value2;
    this.props.parentCallback2(min, max);
    event.preventDefault();
  };
  

  render() {
    return (
      <div className="Slider">
        <h1>2. Set Your Budget</h1>
        <Grid padded>
          <Grid.Column width={16}>
            <Segment>
              <h2>Min Price</h2>
              <p>
                <Slider
                  color="teal"
                  inverted={false}
                  settings={{
                    start: this.state.value1,
                    min: 0,
                    max: 1000,
                    step: 1,
                    onChange: (value) => {
                      this.setState({
                        value1: value
                      });
                    }
                  }}
                />
              </p>
              <Label color="teal">{this.state.value1}</Label>
              <h2>Max Price</h2>
              <p>
                <Slider
                  color="teal"
                  inverted={false}
                  settings={{
                    start: this.state.value1,
                    min: 0,
                    max: 1000,
                    step: 1,
                    onChange: (value) => {
                      this.setState({
                        value2: value
                      });
                    }
                  }}
                />
                <Label color="teal">{this.state.value2}</Label>
              </p>
            </Segment>
          </Grid.Column>
        </Grid>
        {/* Conditional rendering of error message*/}
        {this.state.value1 >= this.state.value2 && (
          <p> ERROR: your max price  must be greater than your min price</p>
        )}
<NextPage3 props = {this.state.value1} props2 = {this.state.value2} buttonHandler={this.onTrigger} />
      </div>
    );
  }
}
//page class
class NextPage3 extends Component {
  render() {
    // get the buttonHandler prop from
    // this.props - we use this in the onClick
    // function in the button below.
    const min = this.props.props
    const max = this.props.props2
    const buttonHandler = this.props.buttonHandler;
    const isenabled = max > min

    return (
      <div className="NextPageComponent">
        <br />
        <button disabled={!isenabled} type="button" class="btn btn-primary" onClick={buttonHandler}>
          Choose Your Finish
        </button>
      </div>
    ); // end of return statement
  } // end of render function
} // end of class
export default SliderScale;
